
package ex.pkg21;

import java.util.Scanner;

public class Main {

    
    public static void main(String[] args) {
      
        
        StudentListings database = new StudentListings();
        
        database.MainLoop(database);
    }

}
